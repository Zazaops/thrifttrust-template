# ThriftTrust Template

This is a portable version of the ThriftTrust project template, exported from Create.xyz.

---

To run locally:
```
npm install
npm run dev
```